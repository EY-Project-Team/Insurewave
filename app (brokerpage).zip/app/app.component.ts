import { Component } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms'
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Broker';
  contactForm = new FormGroup({
  Contract_Id: new FormControl(),
  INSURER: new FormControl(),

})
onSubmit(){
  console.log(this.contactForm.value);
}
Contract_Id:any=[
]
Insurer:any=[
]
}


